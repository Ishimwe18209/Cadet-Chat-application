# final-project-team-3
final-project-team-3 created by GitHub Classroom

Ruby Version: 3.0.1 p64
Social Media site built with Ruby on Rails!
