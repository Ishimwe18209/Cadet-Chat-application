class PublicController < ApplicationController
	def homepage

	end
end
